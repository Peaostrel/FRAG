const fs=require('node:fs');
const path=require('node:path');
const os=require('node:os');
const {createRequire}=require('node:module');
const {spawn}=require('node:child_process');
const {getAsset}=require('node:sea');
const {gunzipSync}=require('node:zlib');
const dataRoot=process.env.FRAG_HOME||path.join(process.env.LOCALAPPDATA||path.join(os.homedir(),'.local','share'),'FRAG');
function openBrowser(url){
 if(process.env.FRAG_NO_BROWSER==='1')return;
 let child;if(process.platform==='win32')child=spawn('rundll32.exe',['url.dll,FileProtocolHandler',url],{detached:true,stdio:'ignore',windowsHide:true});
 else if(process.platform==='darwin')child=spawn('open',[url],{detached:true,stdio:'ignore'});
 else child=spawn('xdg-open',[url],{detached:true,stdio:'ignore'});
 child.on('error',()=>console.log('Откройте адрес в браузере: '+url));child.unref();
}
async function run(){
 process.title='FRAG — Cyber Lounge';fs.mkdirSync(dataRoot,{recursive:true,mode:0o700});
 const instanceFile=path.join(dataRoot,'running.json');
 try{const existing=JSON.parse(fs.readFileSync(instanceFile,'utf8'));if(Number.isInteger(existing.port)&&existing.port>0&&existing.port<65536){const url='http://localhost:'+existing.port;const response=await fetch(url+'/desktop-health',{signal:AbortSignal.timeout(1200)});const data=await response.json();if(data.app==='FRAG_DESKTOP_V1'){openBrowser(url);console.log('FRAG уже работает: '+url);return;}}}catch{}
 const appRoot=path.join(dataRoot,'application-v1');fs.mkdirSync(appRoot,{recursive:true,mode:0o700});
 const files=JSON.parse(gunzipSync(Buffer.from(getAsset('application'))).toString('utf8'));
 for(const [name,base64] of Object.entries(files)){const destination=path.resolve(appRoot,name);if(!destination.startsWith(appRoot+path.sep))throw Error('Invalid packaged path');fs.mkdirSync(path.dirname(destination),{recursive:true});fs.writeFileSync(destination,Buffer.from(base64,'base64'));}
 const localRequire=createRequire(path.join(appRoot,'launcher.cjs'));
 const {createClubServer}=localRequire('./server.mjs');
 const {hashPassword}=localRequire('./lib/club-api.mjs');
 const {server,DB}=createClubServer({dbPath:path.join(dataRoot,'frag.sqlite'),publicUrl:'',port:0,host:'127.0.0.1',adminCode:''});
 const hasAdmin=await DB.prepare("SELECT id FROM users WHERE role='admin' LIMIT 1").first();
 if(!hasAdmin){
  const password='FRAG-'+require('node:crypto').randomBytes(12).toString('base64url');
  const account={email:'admin@frag.local',name:'Администратор FRAG'};
  // Generate a local administrator explicitly during desktop bootstrap, never in public registration.
  const existing=await DB.prepare('SELECT id FROM users WHERE email=?').bind(account.email).first();
  if(existing)account.email='admin-'+Date.now()+'@frag.local';
  await DB.prepare("INSERT INTO users (id,email,name,password_hash,role,created) VALUES (?,?,?,?,'admin',?)").bind(require('node:crypto').randomUUID(),account.email,account.name,await hashPassword(password,600000),Date.now()).run();
  fs.writeFileSync(path.join(dataRoot,'administrator.txt'),'Первоначальный вход администратора FRAG\r\n\r\nПочта: '+account.email+'\r\nПароль: '+password+'\r\n\r\nЭти данные предназначены только владельцу этого компьютера.\r\n',{mode:0o600});
 }
 const original=server.listeners('request')[0];server.removeListener('request',original);server.on('request',(req,res)=>{if(req.method==='GET'&&req.url==='/desktop-health'){res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify({app:'FRAG_DESKTOP_V1'}));return}original(req,res)});
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve)});
 const port=server.address().port,url='http://localhost:'+port;fs.writeFileSync(instanceFile,JSON.stringify({port,pid:process.pid}),{mode:0o600});
 console.log('\n  FRAG / CYBER LOUNGE\n  ──────────────────────────\n  Сайт запущен: '+url+'\n  Браузер откроется автоматически.\n\n  Не закрывайте это окно, пока пользуетесь сайтом.\n  Закрытие окна останавливает сайт; данные сохраняются.\n\n  База: '+path.join(dataRoot,'frag.sqlite')+'\n');
 const credentials=path.join(dataRoot,'administrator.txt');if(fs.existsSync(credentials)){console.log(fs.readFileSync(credentials,'utf8'));console.log('  Данные входа также сохранены: '+credentials+'\n');}
 openBrowser(url);
 const cleanup=()=>{try{const current=JSON.parse(fs.readFileSync(instanceFile,'utf8'));if(current.pid===process.pid)fs.unlinkSync(instanceFile)}catch{}};
 process.once('exit',cleanup);const stop=()=>server.close(()=>{DB.close();process.exit(0)});process.once('SIGINT',stop);process.once('SIGTERM',stop);
}
run().catch(error=>{console.error('\nFRAG не удалось запустить:\n'+error.stack+'\n');try{fs.mkdirSync(dataRoot,{recursive:true});fs.appendFileSync(path.join(dataRoot,'error.log'),new Date().toISOString()+' '+error.stack+'\n')}catch{}if(process.stdin.isTTY){console.log('Нажмите Enter, чтобы закрыть окно.');process.stdin.resume();process.stdin.once('data',()=>process.exit(1))}else process.exitCode=1});
